/********************************************************************************
** Form generated from reading UI file 'task2.ui'
**
** Created by: Qt User Interface Compiler version 6.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TASK2_H
#define UI_TASK2_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Task2
{
public:
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QLabel *label_2;
    QLineEdit *lineEdit_result;
    QLabel *label_var;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton_exit;
    QPushButton *pushButton_check;
    QLabel *label_login;

    void setupUi(QWidget *Task2)
    {
        if (Task2->objectName().isEmpty())
            Task2->setObjectName("Task2");
        Task2->resize(513, 424);
        gridLayoutWidget = new QWidget(Task2);
        gridLayoutWidget->setObjectName("gridLayoutWidget");
        gridLayoutWidget->setGeometry(QRect(50, 50, 391, 331));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setObjectName("gridLayout");
        gridLayout->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(gridLayoutWidget);
        label_2->setObjectName("label_2");

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        lineEdit_result = new QLineEdit(gridLayoutWidget);
        lineEdit_result->setObjectName("lineEdit_result");

        gridLayout->addWidget(lineEdit_result, 1, 1, 1, 1);

        label_var = new QLabel(gridLayoutWidget);
        label_var->setObjectName("label_var");
        label_var->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));

        gridLayout->addWidget(label_var, 0, 0, 1, 2);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName("horizontalLayout");
        pushButton_exit = new QPushButton(gridLayoutWidget);
        pushButton_exit->setObjectName("pushButton_exit");

        horizontalLayout->addWidget(pushButton_exit);

        pushButton_check = new QPushButton(gridLayoutWidget);
        pushButton_check->setObjectName("pushButton_check");

        horizontalLayout->addWidget(pushButton_check);


        gridLayout->addLayout(horizontalLayout, 2, 0, 1, 2);

        label_login = new QLabel(Task2);
        label_login->setObjectName("label_login");
        label_login->setGeometry(QRect(380, 30, 63, 20));

        retranslateUi(Task2);

        QMetaObject::connectSlotsByName(Task2);
    } // setupUi

    void retranslateUi(QWidget *Task2)
    {
        Task2->setWindowTitle(QCoreApplication::translate("Task2", "Form", nullptr));
        label_2->setText(QCoreApplication::translate("Task2", "result", nullptr));
        label_var->setText(QString());
        pushButton_exit->setText(QCoreApplication::translate("Task2", "Exit", nullptr));
        pushButton_check->setText(QCoreApplication::translate("Task2", "Check", nullptr));
        label_login->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Task2: public Ui_Task2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TASK2_H
