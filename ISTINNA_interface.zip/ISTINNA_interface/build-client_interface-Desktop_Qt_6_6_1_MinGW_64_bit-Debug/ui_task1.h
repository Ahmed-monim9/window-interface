/********************************************************************************
** Form generated from reading UI file 'task1.ui'
**
** Created by: Qt User Interface Compiler version 6.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TASK1_H
#define UI_TASK1_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Task1
{
public:
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QLineEdit *lineEdit_n;
    QLabel *label_2;
    QLineEdit *lineEdit_a_b;
    QLineEdit *lineEdit_f;
    QLabel *label;
    QLabel *label_3;
    QLabel *label_4;
    QLineEdit *lineEdit_result;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton_exit;
    QPushButton *pushButton_check;
    QLabel *label_var;
    QLabel *label_login;

    void setupUi(QWidget *Task1)
    {
        if (Task1->objectName().isEmpty())
            Task1->setObjectName("Task1");
        Task1->resize(404, 349);
        gridLayoutWidget = new QWidget(Task1);
        gridLayoutWidget->setObjectName("gridLayoutWidget");
        gridLayoutWidget->setGeometry(QRect(30, 60, 351, 261));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setObjectName("gridLayout");
        gridLayout->setContentsMargins(0, 0, 0, 0);
        lineEdit_n = new QLineEdit(gridLayoutWidget);
        lineEdit_n->setObjectName("lineEdit_n");

        gridLayout->addWidget(lineEdit_n, 2, 1, 1, 1);

        label_2 = new QLabel(gridLayoutWidget);
        label_2->setObjectName("label_2");

        gridLayout->addWidget(label_2, 0, 0, 1, 1);

        lineEdit_a_b = new QLineEdit(gridLayoutWidget);
        lineEdit_a_b->setObjectName("lineEdit_a_b");

        gridLayout->addWidget(lineEdit_a_b, 1, 1, 1, 1);

        lineEdit_f = new QLineEdit(gridLayoutWidget);
        lineEdit_f->setObjectName("lineEdit_f");

        gridLayout->addWidget(lineEdit_f, 0, 1, 1, 1);

        label = new QLabel(gridLayoutWidget);
        label->setObjectName("label");

        gridLayout->addWidget(label, 1, 0, 1, 1);

        label_3 = new QLabel(gridLayoutWidget);
        label_3->setObjectName("label_3");

        gridLayout->addWidget(label_3, 3, 0, 1, 1);

        label_4 = new QLabel(gridLayoutWidget);
        label_4->setObjectName("label_4");

        gridLayout->addWidget(label_4, 2, 0, 1, 1);

        lineEdit_result = new QLineEdit(gridLayoutWidget);
        lineEdit_result->setObjectName("lineEdit_result");

        gridLayout->addWidget(lineEdit_result, 3, 1, 1, 1);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName("horizontalLayout");
        pushButton_exit = new QPushButton(gridLayoutWidget);
        pushButton_exit->setObjectName("pushButton_exit");

        horizontalLayout->addWidget(pushButton_exit);

        pushButton_check = new QPushButton(gridLayoutWidget);
        pushButton_check->setObjectName("pushButton_check");

        horizontalLayout->addWidget(pushButton_check);


        gridLayout->addLayout(horizontalLayout, 4, 0, 1, 2);

        label_var = new QLabel(Task1);
        label_var->setObjectName("label_var");
        label_var->setGeometry(QRect(250, 10, 63, 20));
        label_login = new QLabel(Task1);
        label_login->setObjectName("label_login");
        label_login->setGeometry(QRect(250, 20, 63, 20));

        retranslateUi(Task1);

        QMetaObject::connectSlotsByName(Task1);
    } // setupUi

    void retranslateUi(QWidget *Task1)
    {
        Task1->setWindowTitle(QCoreApplication::translate("Task1", "Form", nullptr));
        label_2->setText(QCoreApplication::translate("Task1", "F(a)", nullptr));
        label->setText(QCoreApplication::translate("Task1", "[a, b]", nullptr));
        label_3->setText(QCoreApplication::translate("Task1", "result", nullptr));
        label_4->setText(QCoreApplication::translate("Task1", "eps", nullptr));
        pushButton_exit->setText(QCoreApplication::translate("Task1", "Exit", nullptr));
        pushButton_check->setText(QCoreApplication::translate("Task1", "Check", nullptr));
        label_var->setText(QString());
        label_login->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Task1: public Ui_Task1 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TASK1_H
