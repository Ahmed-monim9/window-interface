/********************************************************************************
** Form generated from reading UI file 'auth_window.ui'
**
** Created by: Qt User Interface Compiler version 6.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AUTH_WINDOW_H
#define UI_AUTH_WINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_auth_window
{
public:
    QWidget *centralwidget;
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QPushButton *pushButton_auth;
    QPushButton *pushButton_change;
    QLineEdit *lineEdit_log;
    QLineEdit *lineEdit_pass;
    QPushButton *pushButton_register;
    QLineEdit *lineEdit_email;
    QMenuBar *menubar;
    QMenu *menu;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *auth_window)
    {
        if (auth_window->objectName().isEmpty())
            auth_window->setObjectName("auth_window");
        auth_window->resize(603, 311);
        centralwidget = new QWidget(auth_window);
        centralwidget->setObjectName("centralwidget");
        gridLayoutWidget = new QWidget(centralwidget);
        gridLayoutWidget->setObjectName("gridLayoutWidget");
        gridLayoutWidget->setGeometry(QRect(110, 50, 404, 130));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setObjectName("gridLayout");
        gridLayout->setHorizontalSpacing(0);
        gridLayout->setContentsMargins(0, 0, 0, 0);
        pushButton_auth = new QPushButton(gridLayoutWidget);
        pushButton_auth->setObjectName("pushButton_auth");

        gridLayout->addWidget(pushButton_auth, 3, 0, 1, 1);

        pushButton_change = new QPushButton(gridLayoutWidget);
        pushButton_change->setObjectName("pushButton_change");

        gridLayout->addWidget(pushButton_change, 3, 2, 1, 1);

        lineEdit_log = new QLineEdit(gridLayoutWidget);
        lineEdit_log->setObjectName("lineEdit_log");

        gridLayout->addWidget(lineEdit_log, 0, 0, 1, 3);

        lineEdit_pass = new QLineEdit(gridLayoutWidget);
        lineEdit_pass->setObjectName("lineEdit_pass");
        lineEdit_pass->setEchoMode(QLineEdit::Password);

        gridLayout->addWidget(lineEdit_pass, 1, 0, 1, 3);

        pushButton_register = new QPushButton(gridLayoutWidget);
        pushButton_register->setObjectName("pushButton_register");

        gridLayout->addWidget(pushButton_register, 3, 1, 1, 1);

        lineEdit_email = new QLineEdit(gridLayoutWidget);
        lineEdit_email->setObjectName("lineEdit_email");

        gridLayout->addWidget(lineEdit_email, 2, 0, 1, 3);

        auth_window->setCentralWidget(centralwidget);
        menubar = new QMenuBar(auth_window);
        menubar->setObjectName("menubar");
        menubar->setGeometry(QRect(0, 0, 603, 26));
        menu = new QMenu(menubar);
        menu->setObjectName("menu");
        auth_window->setMenuBar(menubar);
        statusbar = new QStatusBar(auth_window);
        statusbar->setObjectName("statusbar");
        auth_window->setStatusBar(statusbar);

        menubar->addAction(menu->menuAction());

        retranslateUi(auth_window);

        QMetaObject::connectSlotsByName(auth_window);
    } // setupUi

    void retranslateUi(QMainWindow *auth_window)
    {
        auth_window->setWindowTitle(QCoreApplication::translate("auth_window", "auth_window", nullptr));
        pushButton_auth->setText(QCoreApplication::translate("auth_window", "\320\220\320\262\321\202\320\276\321\200\320\270\320\267\320\276\320\262\320\260\321\202\321\214\321\201\321\217", nullptr));
        pushButton_change->setText(QCoreApplication::translate("auth_window", "\320\230\320\267\320\274\320\265\320\275\320\270\321\202\321\214 \321\200\320\265\320\266\320\270\320\274", nullptr));
        lineEdit_log->setPlaceholderText(QCoreApplication::translate("auth_window", "\320\233\320\276\320\263\320\270\320\275", nullptr));
        lineEdit_pass->setPlaceholderText(QCoreApplication::translate("auth_window", "\320\237\320\260\321\200\320\276\320\273\321\214", nullptr));
        pushButton_register->setText(QCoreApplication::translate("auth_window", "\320\227\320\260\321\200\320\265\320\263\320\270\321\201\321\202\321\200\320\270\321\200\320\276\320\262\320\260\321\202\321\214\321\201\321\217", nullptr));
        menu->setTitle(QCoreApplication::translate("auth_window", "\320\220\320\262\321\202\320\276\321\200\320\270\320\267\320\260\321\206\320\270\321\217", nullptr));
    } // retranslateUi

};

namespace Ui {
    class auth_window: public Ui_auth_window {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AUTH_WINDOW_H
