/********************************************************************************
** Form generated from reading UI file 'stat.ui'
**
** Created by: Qt User Interface Compiler version 6.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STAT_H
#define UI_STAT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Stat
{
public:
    QTableWidget *tableWidget_stat;
    QLabel *label;
    QLabel *label_2;
    QPushButton *pushButton_exit;
    QPushButton *pushButton_update;
    QLabel *label_login;

    void setupUi(QWidget *Stat)
    {
        if (Stat->objectName().isEmpty())
            Stat->setObjectName("Stat");
        Stat->resize(463, 375);
        tableWidget_stat = new QTableWidget(Stat);
        if (tableWidget_stat->columnCount() < 2)
            tableWidget_stat->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget_stat->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget_stat->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        if (tableWidget_stat->rowCount() < 1)
            tableWidget_stat->setRowCount(1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget_stat->setVerticalHeaderItem(0, __qtablewidgetitem2);
        tableWidget_stat->setObjectName("tableWidget_stat");
        tableWidget_stat->setGeometry(QRect(70, 140, 341, 81));
        label = new QLabel(Stat);
        label->setObjectName("label");
        label->setGeometry(QRect(340, 70, 63, 20));
        label_2 = new QLabel(Stat);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(140, 40, 121, 20));
        pushButton_exit = new QPushButton(Stat);
        pushButton_exit->setObjectName("pushButton_exit");
        pushButton_exit->setGeometry(QRect(70, 290, 93, 29));
        pushButton_update = new QPushButton(Stat);
        pushButton_update->setObjectName("pushButton_update");
        pushButton_update->setGeometry(QRect(290, 290, 93, 29));
        label_login = new QLabel(Stat);
        label_login->setObjectName("label_login");
        label_login->setGeometry(QRect(360, 30, 63, 20));

        retranslateUi(Stat);

        QMetaObject::connectSlotsByName(Stat);
    } // setupUi

    void retranslateUi(QWidget *Stat)
    {
        Stat->setWindowTitle(QCoreApplication::translate("Stat", "Form", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tableWidget_stat->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("Stat", "task1", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget_stat->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("Stat", "task2", nullptr));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget_stat->verticalHeaderItem(0);
        ___qtablewidgetitem2->setText(QCoreApplication::translate("Stat", "correct", nullptr));
        label->setText(QString());
        label_2->setText(QCoreApplication::translate("Stat", "<html><head/><body><p align=\"center\"><span style=\" font-size:11pt;\">Statics</span></p></body></html>", nullptr));
        pushButton_exit->setText(QCoreApplication::translate("Stat", "exit", nullptr));
        pushButton_update->setText(QCoreApplication::translate("Stat", "update", nullptr));
        label_login->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Stat: public Ui_Stat {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STAT_H
