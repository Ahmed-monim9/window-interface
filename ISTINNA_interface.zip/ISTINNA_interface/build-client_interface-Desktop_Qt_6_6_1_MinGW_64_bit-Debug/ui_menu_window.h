/********************************************************************************
** Form generated from reading UI file 'menu_window.ui'
**
** Created by: Qt User Interface Compiler version 6.6.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MENU_WINDOW_H
#define UI_MENU_WINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_menu_window
{
public:
    QLabel *label_login;
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QPushButton *pushButton_task2;
    QPushButton *pushButton_task1;
    QPushButton *pushButton_exit;
    QPushButton *pushButton_stat;

    void setupUi(QDialog *menu_window)
    {
        if (menu_window->objectName().isEmpty())
            menu_window->setObjectName("menu_window");
        menu_window->resize(501, 377);
        label_login = new QLabel(menu_window);
        label_login->setObjectName("label_login");
        label_login->setGeometry(QRect(200, 40, 63, 20));
        gridLayoutWidget = new QWidget(menu_window);
        gridLayoutWidget->setObjectName("gridLayoutWidget");
        gridLayoutWidget->setGeometry(QRect(20, 50, 451, 261));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setObjectName("gridLayout");
        gridLayout->setContentsMargins(0, 0, 0, 0);
        pushButton_task2 = new QPushButton(gridLayoutWidget);
        pushButton_task2->setObjectName("pushButton_task2");

        gridLayout->addWidget(pushButton_task2, 0, 1, 1, 1);

        pushButton_task1 = new QPushButton(gridLayoutWidget);
        pushButton_task1->setObjectName("pushButton_task1");

        gridLayout->addWidget(pushButton_task1, 0, 0, 1, 1);

        pushButton_exit = new QPushButton(gridLayoutWidget);
        pushButton_exit->setObjectName("pushButton_exit");

        gridLayout->addWidget(pushButton_exit, 1, 0, 1, 1);

        pushButton_stat = new QPushButton(gridLayoutWidget);
        pushButton_stat->setObjectName("pushButton_stat");

        gridLayout->addWidget(pushButton_stat, 1, 1, 1, 1);


        retranslateUi(menu_window);

        QMetaObject::connectSlotsByName(menu_window);
    } // setupUi

    void retranslateUi(QDialog *menu_window)
    {
        menu_window->setWindowTitle(QCoreApplication::translate("menu_window", "Dialog", nullptr));
        label_login->setText(QString());
        pushButton_task2->setText(QCoreApplication::translate("menu_window", "Task2", nullptr));
        pushButton_task1->setText(QCoreApplication::translate("menu_window", "Task1", nullptr));
        pushButton_exit->setText(QCoreApplication::translate("menu_window", "Exit", nullptr));
        pushButton_stat->setText(QCoreApplication::translate("menu_window", "Stat", nullptr));
    } // retranslateUi

};

namespace Ui {
    class menu_window: public Ui_menu_window {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MENU_WINDOW_H
