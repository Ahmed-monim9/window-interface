/********************************************************************************
** Form generated from reading UI file 'register_window.ui'
**
** Created by: Qt User Interface Compiler version 6.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REGISTER_WINDOW_H
#define UI_REGISTER_WINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_register_window
{
public:
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QPushButton *pushButton_register;
    QPushButton *pushButton_back;
    QLineEdit *lineEdit_pass2;
    QLineEdit *lineEdit_pass;
    QLineEdit *lineEdit_email;
    QLineEdit *lineEdit_log;

    void setupUi(QDialog *register_window)
    {
        if (register_window->objectName().isEmpty())
            register_window->setObjectName("register_window");
        register_window->resize(400, 300);
        gridLayoutWidget = new QWidget(register_window);
        gridLayoutWidget->setObjectName("gridLayoutWidget");
        gridLayoutWidget->setGeometry(QRect(70, 80, 251, 131));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setObjectName("gridLayout");
        gridLayout->setContentsMargins(0, 0, 0, 0);
        pushButton_register = new QPushButton(gridLayoutWidget);
        pushButton_register->setObjectName("pushButton_register");

        gridLayout->addWidget(pushButton_register, 4, 0, 1, 1);

        pushButton_back = new QPushButton(gridLayoutWidget);
        pushButton_back->setObjectName("pushButton_back");

        gridLayout->addWidget(pushButton_back, 4, 1, 1, 1);

        lineEdit_pass2 = new QLineEdit(gridLayoutWidget);
        lineEdit_pass2->setObjectName("lineEdit_pass2");

        gridLayout->addWidget(lineEdit_pass2, 3, 0, 1, 2);

        lineEdit_pass = new QLineEdit(gridLayoutWidget);
        lineEdit_pass->setObjectName("lineEdit_pass");

        gridLayout->addWidget(lineEdit_pass, 2, 0, 1, 2);

        lineEdit_email = new QLineEdit(gridLayoutWidget);
        lineEdit_email->setObjectName("lineEdit_email");

        gridLayout->addWidget(lineEdit_email, 1, 0, 1, 2);

        lineEdit_log = new QLineEdit(gridLayoutWidget);
        lineEdit_log->setObjectName("lineEdit_log");

        gridLayout->addWidget(lineEdit_log, 0, 0, 1, 2);


        retranslateUi(register_window);

        QMetaObject::connectSlotsByName(register_window);
    } // setupUi

    void retranslateUi(QDialog *register_window)
    {
        register_window->setWindowTitle(QCoreApplication::translate("register_window", "Dialog", nullptr));
        pushButton_register->setText(QCoreApplication::translate("register_window", "\320\227\320\260\321\200\320\265\320\263\320\270\321\201\321\202\321\200\320\270\321\200\320\276\320\262\320\260\321\202\321\214\321\201\321\217", nullptr));
        pushButton_back->setText(QCoreApplication::translate("register_window", "\320\222\320\265\321\200\320\275\321\203\321\202\321\214\321\201\321\217", nullptr));
        lineEdit_pass2->setPlaceholderText(QCoreApplication::translate("register_window", "\320\237\320\276\320\262\321\202\320\276\321\200\320\270\321\202\320\265 \320\277\320\260\321\200\320\276\320\273\321\214", nullptr));
        lineEdit_pass->setPlaceholderText(QCoreApplication::translate("register_window", "\320\237\320\260\321\200\320\276\320\273\321\214", nullptr));
        lineEdit_email->setPlaceholderText(QCoreApplication::translate("register_window", "\320\237\320\276\321\207\321\202\320\260", nullptr));
        lineEdit_log->setPlaceholderText(QCoreApplication::translate("register_window", "\320\233\320\276\320\263\320\270\320\275", nullptr));
    } // retranslateUi

};

namespace Ui {
    class register_window: public Ui_register_window {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REGISTER_WINDOW_H
