/********************************************************************************
** Form generated from reading UI file 'menu_window.ui'
**
** Created by: Qt User Interface Compiler version 6.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MENU_WINDOW_H
#define UI_MENU_WINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>

QT_BEGIN_NAMESPACE

class Ui_menu_window
{
public:

    void setupUi(QDialog *menu_window)
    {
        if (menu_window->objectName().isEmpty())
            menu_window->setObjectName("menu_window");
        menu_window->resize(400, 300);

        retranslateUi(menu_window);

        QMetaObject::connectSlotsByName(menu_window);
    } // setupUi

    void retranslateUi(QDialog *menu_window)
    {
        menu_window->setWindowTitle(QCoreApplication::translate("menu_window", "Dialog", nullptr));
    } // retranslateUi

};

namespace Ui {
    class menu_window: public Ui_menu_window {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MENU_WINDOW_H
